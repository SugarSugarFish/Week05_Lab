// 临时诊断：复刻 index.html 的 RK4 与主循环时间步，检查阻尼是否真的耗散能量
// 用法: node .verify-tmp/diag-damping.mjs
const PPM = 200;
const THETA0 = Math.PI / 4;
const SUB_DT = 0.001;

function run(c, g = 9.8, lenPx = 200, frameMs = 1000 / 60, seconds = 40) {
  const L = lenPx / PPM;
  let theta = THETA0, omega = 0, simTime = 0;

  const accelAt = (th, om) => -(g / L) * Math.sin(th) - c * om;
  function rk4(th, om, h) {
    const k1t = om, k1o = accelAt(th, om);
    const k2t = om + 0.5 * h * k1o, k2o = accelAt(th + 0.5 * h * k1t, om + 0.5 * h * k1o);
    const k3t = om + 0.5 * h * k2o, k3o = accelAt(th + 0.5 * h * k2t, om + 0.5 * h * k2o);
    const k4t = om + h * k3o, k4o = accelAt(th + h * k3t, om + h * k3o);
    return {
      th: th + (h / 6) * (k1t + 2 * k2t + 2 * k3t + k4t),
      om: om + (h / 6) * (k1o + 2 * k2o + 2 * k3o + k4o)
    };
  }

  const dt = frameMs / 1000;
  const frames = Math.round(seconds / dt);
  const env = [];
  let acc = 0, peak = 0;
  for (let i = 0; i < frames; i++) {
    const n = Math.min(60, Math.max(1, Math.ceil(dt / SUB_DT)));
    const h = dt / n;
    for (let k = 0; k < n; k++) {
      const s = rk4(theta, omega, h);
      theta = s.th; omega = s.om;
    }
    simTime += dt;
    if (c > 0 && Math.abs(theta) < 3.5e-4 && Math.abs(omega) < 3.5e-4) { theta = 0; omega = 0; }
    peak = Math.max(peak, Math.abs(theta * 180 / Math.PI));
    acc += dt;
    if (acc >= 2 - 1e-9) { env.push(peak); peak = 0; acc = 0; }
  }
  return { env, simTime, endTh: theta * 180 / Math.PI, endOm: omega };
}

console.log('每 2s 的 |θ| 峰值包络（°）');
for (const c of [0, 0.001, 0.005, 0.010]) {
  const r = run(c);
  const theory = `理论包络 e^(-c t/2) 末值 ${(45 * Math.exp(-c * 40 / 2)).toFixed(2)}°`;
  console.log(`\nc=${c}  ${theory}`);
  console.log('  ' + r.env.map((v) => v.toFixed(1)).join('  '));
  console.log(`  末态 θ=${r.endTh.toFixed(2)}° ω=${r.endOm.toFixed(4)}  simTime=${r.simTime.toFixed(2)}s`);
}

// 子步长敏感性：若子步越小越接近真实耗散，说明是积分步长问题
console.log('\n子步长敏感性（c=0.010，末 2s 峰值）');
for (const sub of [0.002, 0.001, 0.0005, 0.0001]) {
  const saved = SUB_DT;
  // 直接内联一份带自定义 sub 的简化积分
  const L = 200 / PPM, c = 0.010, dt = 1 / 60;
  let theta = THETA0, omega = 0, peak = 0, acc = 0;
  const accelAt = (th, om) => -(9.8 / L) * Math.sin(th) - c * om;
  function rk4(th, om, h) {
    const k1t = om, k1o = accelAt(th, om);
    const k2t = om + 0.5 * h * k1o, k2o = accelAt(th + 0.5 * h * k1t, om + 0.5 * h * k1o);
    const k3t = om + 0.5 * h * k2o, k3o = accelAt(th + 0.5 * h * k2t, om + 0.5 * h * k2o);
    const k4t = om + h * k3o, k4o = accelAt(th + h * k3t, om + h * k3o);
    return { th: th + (h / 6) * (k1t + 2 * k2t + 2 * k3t + k4t), om: om + (h / 6) * (k1o + 2 * k2o + 2 * k3o + k4o) };
  }
  const frames = Math.round(40 / dt);
  for (let i = 0; i < frames; i++) {
    const n = Math.min(2000, Math.max(1, Math.ceil(dt / sub)));
    const h = dt / n;
    for (let k = 0; k < n; k++) { const s = rk4(theta, omega, h); theta = s.th; omega = s.om; }
    acc += dt; peak = Math.max(peak, Math.abs(theta * 180 / Math.PI));
    if (acc >= 2 - 1e-9) { if (i > frames - 130) {} acc = 0; }
  }
  // 单独再跑一次，只取最后 2 秒峰值
  let th2 = THETA0, om2 = 0, p2 = 0; acc = 0;
  const frames2 = Math.round(40 / dt);
  for (let i = 0; i < frames2; i++) {
    const n = Math.min(2000, Math.max(1, Math.ceil(dt / sub)));
    const h = dt / n;
    for (let k = 0; k < n; k++) { const s = rk4(th2, om2, h); th2 = s.th; om2 = s.om; }
    acc += dt;
    if (i >= frames2 - 120) p2 = Math.max(p2, Math.abs(th2 * 180 / Math.PI));
  }
  console.log(`  h=${sub}s -> 末 2s 峰值 ${p2.toFixed(3)}°  （理论 ${(45 * Math.exp(-0.01 * 40 / 2)).toFixed(3)}°）`);
  SUB_DT = saved;
}
