
(function () {
  'use strict';

  // ─────────────────────────────────────────────────────────────
  // 1. 物理参数（可经控制面板实时改写）
  // ─────────────────────────────────────────────────────────────
  var THETA0_DEG  = 45;                         // 初始摆角 45°（固定，重置用）
  var PPM         = 200;                        // 像素/米 标度：200px = 1.000m
  var THETA0      = THETA0_DEG * Math.PI / 180; // 初始摆角（弧度）

  // 运行参数：滑块直接写这里
  var P = {
    lenPx:  200,     // 摆长（显示像素，100 ~ 350）
    g:      9.8,     // 重力加速度 m/s²（1 ~ 25）
    dampC:  0        // 阻尼系数 c（角速度系数，0 ~ 0.010 s⁻¹）
  };

  // 由 P 派生：ω₀ 与无阻尼周期 T
  var LENGTH_M = 0, OMEGA = 0, PERIOD = 0;
  var SUB_DT   = 0.001;    // RK4 固定子步长（秒）
  var TRAIL_TAU = 0.35;    // 拖尾时间常数（秒）
  var TRAIL_MAX = 48;      // 拖尾采样点上限

  function derive() {
    LENGTH_M = P.lenPx / PPM;
    OMEGA    = Math.sqrt(P.g / LENGTH_M);
    PERIOD   = 2 * Math.PI / OMEGA;
  }

  // ─────────────────────────────────────────────────────────────
  // 2. 运行时状态
  // ─────────────────────────────────────────────────────────────
  var canvas = document.getElementById('cv');
  var ctx    = canvas.getContext('2d');
  var el = {
    rL:    document.getElementById('rL'),
    rG:    document.getElementById('rG'),
    rT0:   document.getElementById('rT0'),
    rT:    document.getElementById('rT'),
    rW:    document.getElementById('rW'),
    rC:    document.getElementById('rC'),
    rP:    document.getElementById('rP'),
    rTime: document.getElementById('rTime'),
    state: document.getElementById('state'),
    // 控制面板
    sLen:     document.getElementById('sLen'),
    sLenVal:  document.getElementById('sLenVal'),
    sGrav:    document.getElementById('sGrav'),
    sGravVal: document.getElementById('sGravVal'),
    sDamp:    document.getElementById('sDamp'),
    sDampVal: document.getElementById('sDampVal'),
    reset:    document.getElementById('resetBtn'),
    panel:    document.getElementById('controls')
  };

  var W = 0, H = 0;          // 逻辑尺寸（CSS 像素）
  var DPR = 1;
  var pivot = { x: 0, y: 0 };
  var panelH   = 118;        // 控制面板实测高度（px）
  var dispLen  = 200;        // 摆杆显示长度（摆长过大时等比缩小，仅影响显示）

  var simTime = 0;           // 仿真时间（秒）
  var theta   = THETA0;      // 当前摆角（弧度，自竖直向下起算）
  var omega   = 0;           // 当前角速度（rad/s）
  var timeScale = 1;         // 摆长过大时的显示缩放（仅影响绘制，不影响物理）
  var running = true;
  var trail   = [];          // 拖尾采样点
  var lastTs  = 0;

  // ─────────────────────────────────────────────────────────────
  // 3. 布局 / 高 DPI
  // ─────────────────────────────────────────────────────────────
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = canvas.clientWidth || window.innerWidth;
    H = canvas.clientHeight || window.innerHeight;

    canvas.width  = Math.max(1, Math.round(W * DPR));
    canvas.height = Math.max(1, Math.round(H * DPR));
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);

    // 控制面板实测高度：把它的高度写进 CSS 变量，供提示文字定位
    if (el.panel && el.panel.offsetHeight) {
      panelH = el.panel.offsetHeight;
      document.documentElement.style.setProperty('--panelH', panelH + 'px');
    }

    // 悬点：水平居中；为下方控制面板预留空间后再定竖直位置
    var avail = Math.max(120, H - panelH - 24);
    pivot.x = W / 2;
    pivot.y = Math.max(72, Math.min(H * 0.20, 96 + avail * 0.14));

    layoutPendulum();
    trail.length = 0;
  }

  // 摆长过大时等比缩小"显示长度"，保证不压到控制面板；物理量（L、g）不受影响
  function layoutPendulum() {
    var roomY = Math.max(70, (H - panelH - 24) - pivot.y - 28);
    var roomX = Math.max(70, W / 2 - 30);
    var room  = Math.min(roomY, roomX);
    timeScale = Math.min(1, room / P.lenPx);
    dispLen   = P.lenPx * timeScale;
  }

  // ─────────────────────────────────────────────────────────────
  // 4. 物理：含阻尼的单摆方程  θ″ = −(g/L)·sinθ − c·θ′
  //    （c = 0 时退化为简谐振动，45° 处与解析解 θ₀cos(ωt) 一致到 3 位小数）
  //    用固定步长 RK4 积分：滑块改参数立刻生效，无需重建解析解。
  // ─────────────────────────────────────────────────────────────
  function accelAt(th, om) {
    return -(P.g / LENGTH_M) * Math.sin(th) - P.dampC * om;
  }

  function rk4(th, om, h) {
    var k1t = om,                       k1o = accelAt(th, om);
    var k2t = om + 0.5 * h * k1o,       k2o = accelAt(th + 0.5 * h * k1t, om + 0.5 * h * k1o);
    var k3t = om + 0.5 * h * k2o,       k3o = accelAt(th + 0.5 * h * k2t, om + 0.5 * h * k2o);
    var k4t = om + h * k3o,             k4o = accelAt(th + h * k3t,       om + h * k3o);
    return {
      th: th + (h / 6) * (k1t + 2 * k2t + 2 * k3t + k4t),
      om: om + (h / 6) * (k1o + 2 * k2o + 2 * k3o + k4o)
    };
  }

  function stepPhysics(dt) {
    if (!(dt > 0)) return;
    var n = Math.min(60, Math.max(1, Math.ceil(dt / SUB_DT)));
    var h = dt / n;
    for (var i = 0; i < n; i++) {
      var s = rk4(theta, omega, h);
      theta = s.th;
      omega = s.om;
    }
    simTime += dt;
    // 阻尼耗散：摆角长期落在 0 附近（< 0.02°）且几乎静止时归位，避免残留微幅抖动
    if (P.dampC > 0 && Math.abs(theta) < 3.5e-4 && Math.abs(omega) < 3.5e-4) {
      theta = 0;
      omega = 0;
    }
  }

  function resetMotion() {
    simTime = 0;
    theta   = THETA0;      // 精准回到 45°
    omega   = 0;
    trail.length = 0;
    lastTs = 0;
    hudAcc = 0;
    paintHud();            // 立即刷新读数，避免重置后仍显示旧值
  }

  // ─────────────────────────────────────────────────────────────
  // 5. 绘制
  // ─────────────────────────────────────────────────────────────
  function bobPosition() {
    return {
      x: pivot.x + dispLen * Math.sin(theta),
      y: pivot.y + dispLen * Math.cos(theta)
    };
  }

  function drawBackground() {
    // 深灰科技底色 + 顶部微亮
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#22222f');
    g.addColorStop(0.55, '#1a1a24');
    g.addColorStop(1, '#141420');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // 科技网格
    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(126, 231, 255, 0.045)';
    ctx.beginPath();
    for (var x = 0; x <= W; x += 40) {
      ctx.moveTo(Math.round(x) + 0.5, 0);
      ctx.lineTo(Math.round(x) + 0.5, H);
    }
    for (var y = 0; y <= H; y += 40) {
      ctx.moveTo(0, Math.round(y) + 0.5);
      ctx.lineTo(W, Math.round(y) + 0.5);
    }
    ctx.stroke();
    ctx.restore();

    // 四角晕影，压暗边缘
    var v = ctx.createRadialGradient(
      pivot.x, pivot.y, 0,
      pivot.x, pivot.y, Math.max(W, H) * 0.78
    );
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,0.55)');
    ctx.fillStyle = v;
    ctx.fillRect(0, 0, W, H);
  }

  function drawGuides() {
    ctx.save();

    // 竖直参考线
    ctx.setLineDash([4, 8]);
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(126, 231, 255, 0.20)';
    ctx.beginPath();
    ctx.moveTo(pivot.x, pivot.y);
    ctx.lineTo(pivot.x, pivot.y + dispLen + 34);
    ctx.stroke();

    // 两侧最大摆角边界（不随阻尼变化）
    [-1, 1].forEach(function (s) {
      var ang = s * THETA0;
      var ex = pivot.x + (dispLen + 26) * Math.sin(ang);
      var ey = pivot.y + (dispLen + 26) * Math.cos(ang);
      ctx.strokeStyle = 'rgba(154, 134, 255, 0.22)';
      ctx.beginPath();
      ctx.moveTo(pivot.x, pivot.y);
      ctx.lineTo(ex, ey);
      ctx.stroke();
    });

    ctx.setLineDash([]);

    // 摆动圆弧轨迹
    var rList = timeScale < 1 ? [dispLen, dispLen / timeScale] : [dispLen];
    rList.forEach(function (rr, k) {
      ctx.lineWidth = k ? 1 : 1.5;
      ctx.strokeStyle = k ? 'rgba(154, 134, 255, 0.18)' : 'rgba(154, 134, 255, 0.30)';
      ctx.beginPath();
      ctx.arc(
        pivot.x, pivot.y, rr,
        Math.PI / 2 - THETA0,
        Math.PI / 2 + THETA0
      );
      ctx.stroke();
    });

    ctx.restore();
  }

  function drawTrail() {
    if (trail.length < 2) return;
    var now = simTime;

    ctx.save();
    ctx.lineCap = 'round';
    for (var i = 1; i < trail.length; i++) {
      var p0 = trail[i - 1], p1 = trail[i];
      var age = now - p1.t;
      var a = Math.exp(-age / TRAIL_TAU);
      if (a < 0.02) continue;

      ctx.strokeStyle = 'rgba(126, 231, 255, ' + (a * 0.6).toFixed(3) + ')';
      ctx.lineWidth = 1 + 7 * a;
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawRod(bob) {
    ctx.save();
    ctx.lineCap = 'round';

    // 外发光杆
    ctx.strokeStyle = 'rgba(126, 231, 255, 0.22)';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(pivot.x, pivot.y);
    ctx.lineTo(bob.x, bob.y);
    ctx.stroke();

    // 杆芯
    var lg = ctx.createLinearGradient(pivot.x, pivot.y, bob.x, bob.y);
    lg.addColorStop(0, 'rgba(214, 224, 245, 0.95)');
    lg.addColorStop(1, 'rgba(150, 200, 235, 0.95)');
    ctx.strokeStyle = lg;
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(pivot.x, pivot.y);
    ctx.lineTo(bob.x, bob.y);
    ctx.stroke();

    ctx.restore();
  }

  function drawPivot() {
    ctx.save();

    ctx.beginPath();
    ctx.arc(pivot.x, pivot.y, 9, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(126, 231, 255, 0.10)';
    ctx.fill();

    ctx.beginPath();
    ctx.arc(pivot.x, pivot.y, 5, 0, Math.PI * 2);
    var pg = ctx.createRadialGradient(
      pivot.x - 2, pivot.y - 2, 0.5,
      pivot.x, pivot.y, 5
    );
    pg.addColorStop(0, '#ffffff');
    pg.addColorStop(0.5, '#c8d4ee');
    pg.addColorStop(1, '#5a6480');
    ctx.fillStyle = pg;
    ctx.fill();

    ctx.strokeStyle = 'rgba(126, 231, 255, 0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(pivot.x, pivot.y, 9.5, 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  }

  function drawBob(bob) {
    var R = 16;

    ctx.save();

    // 外层光晕（缓慢呼吸）
    var pulse = 1 + 0.05 * Math.sin(simTime * 3.1);
    var glow = ctx.createRadialGradient(
      bob.x, bob.y, R * 0.6,
      bob.x, bob.y, R * 5.2 * pulse
    );
    glow.addColorStop(0,    'rgba(126, 231, 255, 0.42)');
    glow.addColorStop(0.35, 'rgba(96, 190, 255, 0.16)');
    glow.addColorStop(1,    'rgba(70, 140, 255, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(bob.x, bob.y, R * 5.2 * pulse, 0, Math.PI * 2);
    ctx.fill();

    // 球体自身发光
    ctx.shadowBlur = 30;
    ctx.shadowColor = 'rgba(126, 231, 255, 0.95)';

    var core = ctx.createRadialGradient(
      bob.x - R * 0.35, bob.y - R * 0.40, R * 0.14,
      bob.x, bob.y, R
    );
    core.addColorStop(0,    '#ffffff');
    core.addColorStop(0.30, '#dff6ff');
    core.addColorStop(0.68, '#6ec8ff');
    core.addColorStop(1,    '#2a6ec9');
    ctx.fillStyle = core;
    ctx.beginPath();
    ctx.arc(bob.x, bob.y, R, 0, Math.PI * 2);
    ctx.fill();

    ctx.shadowBlur = 0;

    // 高光点
    ctx.beginPath();
    ctx.arc(bob.x - R * 0.34, bob.y - R * 0.38, R * 0.20, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)';
    ctx.fill();

    // 边缘轮廓
    ctx.strokeStyle = 'rgba(190, 240, 255, 0.65)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(bob.x, bob.y, R, 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  }

  function draw() {
    drawBackground();
    drawGuides();
    drawTrail();

    var bob = bobPosition();
    drawRod(bob);
    drawBob(bob);
    drawPivot();
  }

  // ─────────────────────────────────────────────────────────────
  // 6. 抬头数据刷新（限频，避免每帧写 DOM）
  // ─────────────────────────────────────────────────────────────
  var hudAcc = 0;

  function paintHud() {
    el.rT.textContent    = (theta * 180 / Math.PI).toFixed(2) + '°';
    el.rW.textContent    = omega.toFixed(3) + ' rad/s';
    el.rTime.textContent = simTime.toFixed(2) + ' s';

    // 阻尼系数 c 独立显示：c 很小时 ω₀²·cosθ ≈ ω₀²，避免 0 除
    if (P.dampC > 0) {
      var w02 = P.g / LENGTH_M * Math.max(Math.cos(theta), 0.1);
      el.rC.textContent = P.dampC.toFixed(5) + ' s⁻¹  ( ζ≈' +
                          (P.dampC / (2 * Math.sqrt(w02))).toFixed(4) + ' )';
    } else {
      el.rC.textContent = '0（无阻尼）';
    }
  }

  function updateHud(dt) {
    hudAcc += dt;
    if (hudAcc < 0.06) return;
    hudAcc = 0;
    paintHud();
  }

  function fillStaticHud() {
    el.rT0.textContent = THETA0_DEG + '°';
    syncReadouts();
  }

  // 参数改变后立即刷新所有派生读数（滑块拖动时逐帧调用）
  function syncReadouts() {
    derive();
    el.rL.textContent = P.lenPx + ' px  ( ' + LENGTH_M.toFixed(3) + ' m )';
    el.rG.textContent = P.g.toFixed(1) + ' m/s²';
    el.rP.textContent = PERIOD.toFixed(3) + ' s';

    el.sLenVal.textContent  = P.lenPx + ' px';
    el.sGravVal.textContent = P.g.toFixed(1) + ' m/s²';
    el.sDampVal.textContent = P.dampC.toFixed(4) + ' s⁻¹';
    layoutPendulum();
  }

  // 摆长 / 重力 / 阻尼滑块：改参数不重置相位，物理立即响应
  function bindSliders() {
    el.sLen.addEventListener('input', function () {
      P.lenPx   = parseFloat(this.value) || 0;
      trail.length = 0;
      syncReadouts();
      paintHud();
    });

    el.sGrav.addEventListener('input', function () {
      P.g       = parseFloat(this.value) || 0;
      syncReadouts();
      paintHud();
    });

    el.sDamp.addEventListener('input', function () {
      P.dampC   = parseFloat(this.value) || 0;
      syncReadouts();
      paintHud();
    });
  }

  function setRunning(v) {
    running = v;
    el.state.textContent = v ? '● RUNNING' : '● PAUSED';
    el.state.className = v ? '' : 'paused';
    if (v) lastTs = 0;   // 重新对时，避免暂停期间累积跳变
  }

  // ─────────────────────────────────────────────────────────────
  // 7. 主循环
  // ─────────────────────────────────────────────────────────────
  function frame(ts) {
    if (!lastTs) lastTs = ts;
    var dt = (ts - lastTs) / 1000;
    lastTs = ts;

    // 标签页切换回来时 dt 可能很大，做上限保护
    if (!isFinite(dt) || dt < 0) dt = 0;
    if (dt > 0.05) dt = 0.05;

    if (running) {
      stepPhysics(dt);

      var bob = bobPosition();
      trail.push({ x: bob.x, y: bob.y, t: simTime });
      if (trail.length > TRAIL_MAX) trail.shift();

      updateHud(dt);
    }

    draw();
    requestAnimationFrame(frame);
  }

  // ─────────────────────────────────────────────────────────────
  // 8. 交互
  // ─────────────────────────────────────────────────────────────
  window.addEventListener('resize', resize);

  window.addEventListener('keydown', function (e) {
    var t = e.target;
    // 焦点在滑块/按钮上时不抢快捷键
    if (t && (t.tagName === 'INPUT' || t.tagName === 'BUTTON')) return;

    if (e.code === 'Space' || e.key === ' ') {
      e.preventDefault();
      setRunning(!running);
    } else if (e.key === 'r' || e.key === 'R') {
      resetMotion();
    }
  });

  canvas.addEventListener('pointerdown', function () {
    setRunning(!running);
  });

  // 参数滑块：拖动后立即生效（不重置相位），松开即时释放焦点，恢复空格/R 快捷键
  ['sLen', 'sGrav', 'sDamp'].forEach(function (id) {
    var s = document.getElementById(id);
    if (!s) return;
    s.addEventListener('change', function () { s.blur(); });
  });

  // 重置摆动：摆球精准回到 45° 初始状态
  el.reset.addEventListener('click', function () {
    resetMotion();
    this.blur();
    setRunning(true);
  });

  // ─────────────────────────────────────────────────────────────
  // 9. 启动
  // ─────────────────────────────────────────────────────────────
  bindSliders();
  resize();
  fillStaticHud();
  setRunning(true);
  resetMotion();
  requestAnimationFrame(frame);
})();
